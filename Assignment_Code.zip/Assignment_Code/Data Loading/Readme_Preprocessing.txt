Open Google Chrome and navigate to Google CoLab.
A Open window appears. Click on Upload option from the window.
Click "choose File" and select ADM_Preprocess.ipynb
Click on the small arrow at the top left corner of the screen
Navigate to Files and click on "Upload".
Upload the data files "Posts","Comments" and "Users" from assignment data file.
Run each query on the ipynb file by clicking on the black play button.
Run query one by one and click refresh on the Files column once the query is done.
Do not run all query at once as the input for the next query depends on the output of the previous.
Please Use Google Chrome Browser while executing these Query.
Once you click on the final query, A dialog box will appear to confirm download of multiple files.Click ok.
If you face an error while executing final query. Run it again.
After the last query is executed, 7 files will be downloaded.
--Post_Questions.csv
--Post_Accepted.csv
--Post_Not_Accepted.csv
--Comment_Questions.csv
--Comments_accepted.csv
--Comments_not_accepted.csv
--User.csv

Please refer to Readme_MongoDB next