The Neo4j commands for this project is executed with NEO4J DESKTOP version.
-Download and install Neo4j Desktop from the official neo4j page.
-Open the Neo4J Desktop and you will see the home screen.
-Click on the icon at the top left corner and click on "New" to create a new project.
-Click on "Add Graph". Give Graph Name as "APOC TEST" and Password. Select the latest release from the drop down box "3.5.9" and click create.

Important:<Make sure you are connected to the internet before installing APOC. If there is an issue on internet connectivity, click on option check internet connectivity while installing APOC.>

-APOC will be downloaded and installed and the server is ready to start. Click on "Start" to start the neo4j server.
-Click "Manage" on APOC TEST. Click on Plugins -> Install APOC. 
-Once done,Click on Play button to start the server
-Click on the down arrow in the Icon "Open Folder" and select Import.
-The import folder appears.
-Copy paste the files that has been downloaded as a result of preprocessing step and paste it into this folder. The files required are:
--Comment_Questions
--Comments_accepted
--Comments_not_accepted
--Post_Questions
--Posts_Not_Accepted
--Posts_Accepted
--User

NOTE: The queries are seperated by a new line. A NEW LINE indicates the starting of new query or next query

Close the window and click on "Open Browser" button. The Browser window will now be active.

Copy and paste the following commands in the neo4j browser.

LOAD CSV WITH HEADERS FROM "file:///Post_Questions.csv" AS row
CREATE (n:PostQuestions)
SET n = row,
  n.Id = toInteger(row.Id),
  n.AcceptedAnswerId = toInteger(row.AcceptedAnswerId), n.OwnerUserId = toInteger(row.OwnerUserId),
  n.LastEditorUserId = toInteger(row.LastEditorUserId), n.CreationDate = toString(row.CreationDate),n.LastActivityDate=toString(row.LastActivityDate),
  n.Title=toString(row.Title),n.Tags=split(row.Tags,","),n.AnswerCount = toInteger(n.AnswerCount), n.CommentCount = toInteger(row.CommentCount)

LOAD CSV WITH HEADERS FROM "file:///Post_Not_Accepted.csv" AS row
CREATE (n:PostNotAccepted)
SET n = row,
  n.Id = toInteger(row.Id),n.PostTypeId=toInteger(row.PostTypeId),
  n.OwnerUserId = toInteger(row.OwnerUserId),n.Score=toInteger(row.Score),
  n.LastEditorUserId = toInteger(row.LastEditorUserId), n.CreationDate =toString(row.CreationDate),n.LastActivityDate=toString(row.LastActivityDate), n.CommentCount = toInteger(row.CommentCount), n.ParentId=toInteger(row.ParentId)

LOAD CSV WITH HEADERS FROM "file:///Post_Accepted.csv" AS row
CREATE (n:PostAccepted)
SET n = row,
  n.Id = toInteger(row.Id),n.PostTypeId=toInteger(row.PostTypeId),
  n.OwnerUserId = toInteger(row.OwnerUserId),n.Score=toInteger(row.Score),
  n.LastEditorUserId = toInteger(row.LastEditorUserId), n.CreationDate =toString(row.CreationDate),n.LastActivityDate=toString(row.LastActivityDate), n.CommentCount = toInteger(row.CommentCount), n.ParentId=toInteger(row.ParentId)

MATCH (P:PostQuestions),(N:PostNotAccepted) WHERE P.Id = N.ParentId CREATE (N)-[:ANSWERS]->(P)

MATCH (P:PostQuestions),(N:PostAccepted) WHERE P.Id = N.ParentId CREATE (N)-[:ANSWERS]->(P)

LOAD CSV WITH HEADERS FROM "file:///User.csv" AS row
CREATE (n:User)
SET n=row,
  n.Id = toInteger(row.Id),n.DisplayName=toString(row.DisplayName),n.UpVotes=toInteger(row.UpVotes)

LOAD CSV WITH HEADERS FROM "file:///Comment_Questions.csv" AS row
CREATE (n:Comments)
SET n = row,
  n.Id = toInteger(row.Id),n.PostId=toInteger(row.PostId),
  n.UserId = toInteger(row.UserId),n.CreationDate =toString(row.CreationDate)

MATCH (P:PostQuestions),(N:Comments) WHERE P.Id = N.PostId CREATE (P)-[:HAS]->(N)

MATCH (P:User),(N:Comments) WHERE P.Id = N.UserId CREATE (P)-[:COMMENTS]->(N)

LOAD CSV WITH HEADERS FROM "file:///Comments_accepted.csv" AS row
CREATE (n:Comments)
SET n = row,
  n.Id = toInteger(row.Id),n.PostId=toInteger(row.PostId),
  n.UserId = toInteger(row.UserId),n.CreationDate =toString(row.CreationDate)

MATCH (P:PostAccepted),(N:Comments) WHERE P.Id = N.PostId CREATE (P)-[:HAS]->(N)

MATCH (P:User),(N:Comments) WHERE P.Id = N.UserId CREATE (P)-[:COMMENTS]->(N)

LOAD CSV WITH HEADERS FROM "file:///Comments_not_accepted.csv" AS row
CREATE (n:Comments)
SET n = row,
  n.Id = toInteger(row.Id),n.PostId=toInteger(row.PostId),
  n.UserId = toInteger(row.UserId),n.CreationDate =toString(row.CreationDate)

MATCH (P:PostNotAccepted),(N:Comments) WHERE P.Id = N.PostId CREATE (P)-[:HAS]->(N)

MATCH (P:User),(N:Comments) WHERE P.Id = N.UserId CREATE (P)-[:COMMENTS]->(N)

MATCH (P:User),(N:PostNotAccepted) WHERE P.Id = N.OwnerUserId CREATE (P)-[:POSTS]->(N)

MATCH (P:User),(N:PostAccepted) WHERE P.Id = N.OwnerUserId CREATE (P)-[:POSTS]->(N)

MATCH (P:User),(N:PostQuestions) WHERE P.Id = N.OwnerUserId CREATE (P)-[:POSTS]->(N)

MATCH (P:User),(N:PostNotAccepted) WHERE P.Id = N.LastEditorUserId CREATE (P)-[:EDITS]->(N)

MATCH (P:User),(N:PostAccepted) WHERE P.Id = N.LastEditorUserId CREATE (P)-[:EDITS]->(N)

MATCH (P:User),(N:PostQuestions) WHERE P.Id = N.LastEditorUserId CREATE (P)-[:EDITS]->(N)

CREATE INDEX ON :PostQuestions(Title)

CREATE INDEX ON :PostQuestions(AnswerCount)

CREATE INDEX ON :PostAccepted(OwnerUserId)

CREATE INDEX ON :User(Id)

CREATE INDEX ON :User(UpVotes)

CREATE INDEX ON :PostQuestions(Tags)