STEPS TO IMPORT IN MONGODB:

-Download the MongoDB Community server and MongoDB compass from official page.
-Install MongoDB and follow the below steps.
-Create a repository by creating a directory a directory in your computer say D:\Assignment1\MongoDB.
-Then Open Command Prompt, and navigate to the following directory:
			C:/Program Files/MongoDB/Server/4.0/bin
-To start the server, run mongod.exe --dbpath D:\Assignment1\MongoDB --smallfiles
-Using MongoDB Compass, Connect to the server
-Create a database named "Assignment" by using "Create Database" option
-Create the following collections in the database by using "Create Collection" Option
1)post_questions
2)post_not_accepted
3)post_accepted
4)Comment_Questions
5)Comment_PNA
6)Comments_PA
7)Users

-The ouput of preprocessing README will be utilized here. Replace the file location --file with location of preprocessed output file location.
For Example, if you download your preprocessing files at D: drive, then the --file for all the below queries will be --file D:\<filename>.csv


NOTE: The queries are seperated by a new line. A NEW LINE indicates the starting of new query or next query

Open a new command prompt and navigate to C:/Program Files/MongoDB/Server/4.0/bin. Then Execute the following steps one at a time

mongoimport --db Assignment --collection post_questions --type csv --columnsHaveTypes --fields "_id.int32(),PostTypeId.int32(),AcceptedAnswerId.int32(),CreationDate.string(),Score.int32(),OwnerUserId.int32(),LastEditorUserId.int32(),LastActivityDate.string(),Title.string(),Tags.string(),AnswerCount.int32(),CommentCount.int32()" --file C:\Users\Admin\Desktop\Sem2\ADM\Files\Post_Questions_mongo.csv --ignoreBlanks

mongoimport --db Assignment --collection post_not_accepted --type csv --columnsHaveTypes --fields "_id.int32(),PostTypeId.int32(),CreationDate.string(),Score.int32(),OwnerUserId.int32(),LastEditorUserId.int32(),LastActivityDate.string(),CommentCount.int32(),ParentId.int32()" --file C:\Users\Admin\Desktop\Sem2\ADM\Files\Post_Not_Accepted_mongo.csv --ignoreBlanks

mongoimport --db Assignment --collection post_accepted --type csv --columnsHaveTypes --fields "_id.int32(),PostTypeId.int32(),CreationDate.string(),Score.int32(),OwnerUserId.int32(),LastEditorUserId.int32(),LastActivityDate.string(),CommentCount.int32(),ParentId.int32()" --file C:\Users\Admin\Desktop\Sem2\ADM\Files\Post_Accepted_mongo.csv --ignoreBlanks

mongoimport --db Assignment --collection Comment_Questions --type csv --columnsHaveTypes --fields "_id.int32(),PostId.int32(),CreationDate.string(),UserId.int32()" --file C:\Users\Admin\Desktop\Sem2\ADM\Files\Comment_Questions_mongo.csv --ignoreBlanks

mongoimport --db Assignment --collection Comment_PNA --type csv --columnsHaveTypes --fields "_id.int32(),PostId.int32(),CreationDate.string(),UserId.int32()" --file C:\Users\Admin\Desktop\Sem2\ADM\Files\Comments_not_accepted_mongo.csv --ignoreBlanks

mongoimport --db Assignment --collection Comments_PA --type csv --columnsHaveTypes --fields "_id.int32(),PostId.int32(),CreationDate.string(),UserId.int32()" --file C:\Users\Admin\Desktop\Sem2\ADM\Files\Comments_accepted_mongo.csv --ignoreBlanks

mongoimport --db Assignment --collection Users --type csv --columnsHaveTypes --fields "_id.int32(),DisplayName.string(),UpVotes.int32()" --file C:\Users\Admin\Desktop\Sem2\ADM\Files\User_mongo.csv --ignoreBlanks

Open the Robo3T, Connect it the MongoDB Server. Click on the assignment database and check whether all the databases are correctly imported.
Execute the following commands in a new shell one by one.

db.post_questions.find().forEach(function (doc){
    doc.Tags=doc.Tags.substring(0,doc.Tags.length);
    doc.Tags=doc.Tags.split(',');
    db.post_questions.save(doc)
    });

db.post_questions.find().forEach(function(doc){
doc.CreationDate = new ISODate(doc.CreationDate);
db.post_questions.save(doc)
});

db.post_questions.find().forEach(function(doc){
doc.LastActivityDate = new ISODate(doc.LastActivityDate);
db.post_questions.save(doc)
});

db.post_questions.find().forEach(function(doc){
doc.CreationDate = new Date(doc.CreationDate);
db.post_questions.save(doc)
});


db.post_not_accepted.find().forEach(function(doc){
doc.LastActivityDate = new ISODate(doc.LastActivityDate);
db.post_not_accepted.save(doc)
});

db.post_not_accepted.find().forEach(function(doc){
doc.CreationDate = new Date(doc.CreationDate);
db.post_not_accepted.save(doc)
});


db.post_accepted.find().forEach(function(doc){
doc.LastActivityDate = new ISODate(doc.LastActivityDate);
db.post_accepted.save(doc)
});

db.post_accepted.find().forEach(function(doc){
doc.CreationDate = new Date(doc.CreationDate);
db.post_accepted.save(doc)
});

db.Comment_Questions.find().forEach(function(doc){
doc.CreationDate = new ISODate(doc.CreationDate);
db.Comment_Questions.save(doc)
});

db.Comment_PNA.find().forEach(function(doc){
doc.CreationDate = new ISODate(doc.CreationDate);
db.Comment_PNA.save(doc)
});

db.Comments_PA.find().forEach(function(doc){
doc.CreationDate = new ISODate(doc.CreationDate);
db.Comments_PA.save(doc)
});

db.post_questions.aggregate(
[{$lookup: {
from: "Comment_Questions",
localField: "_id" ,
foreignField: "PostId",
as: "comments"}
},{$out:"post_question_final"}])

db.post_not_accepted.aggregate(
[{$lookup: {
from: "Comment_PNA",
localField: "_id" ,
foreignField: "PostId",
as: "comments"}
},{$out:"post_not_accepted_final"}])

db.post_accepted.aggregate(
[{$lookup: {
from: "Comments_PA",
localField: "_id" ,
foreignField: "PostId",
as: "comments"}
},{$out:"post_accepted_final"}])

db.post_question_final.aggregate(
[{$lookup: {
from: "post_not_accepted_final",
localField: "_id" ,
foreignField: "ParentId",
as: "Unaccepted_answer"}
},{$out:"postinter"}])


db.postinter.aggregate(
[{$lookup: {
from: "post_accepted_final",
localField: "_id" ,
foreignField: "ParentId",
as: "accepted_answer"}
},{$out:"post"}])


db.post.createIndex({AnswerCount:1})

db.post.createIndex({OwnerUserId:1})

db.post.createIndex({LastEditorUserId:1})

db.post.createIndex({Score:1})

db.post.createIndex({Title:1})

db.post.createIndex({AcceptedAnswerId:1})
