db.post.aggregate([
{$project:{Tags:1,Title:1,CreationDate:1,LastActivityDate:1,comments:1,OwnerUserId:1,LastEditorUserId:1,Unaccepted_answer:1,accepted_answer:1,totalusers:1,Unaccepted:{$reduce:{input:"$Unaccepted_answer.comments.UserId",initialValue:[],in:{$concatArrays:["$$value","$$this"]}}},
accepted:{$reduce:{input:"$accepted_answer.comments.UserId",initialValue:[],in:{$concatArrays:["$$value","$$this"]}}}}},
{$addFields: { Users:["$Unaccepted_answer.LastEditorUserId","$accepted_answer.LastEditorUserId","$Unaccepted_answer.OwnerUserId","$accepted_answer.OwnerUserId","$comments.UserId","$Unaccepted","$accepted"]}},
{$project:{Tags:1,Title:1,CreationDate:1,LastActivityDate:1,Values:{$reduce:{input:"$Users",initialValue:["$OwnerUserId","$LastEditorUserId"],in:{$concatArrays:["$$value","$$this"]}}}}},
{$project:{Tags:1,Title:1,CreationDate:1,LastActivityDate:1,Values:{$setUnion:["$Values",[]]}}},
{$project:{Tags:1,Title:1,CreationDate:1,LastActivityDate:1,Values:1,numofUsersParticipated:{$size:"$Values"}}},
{$match:{CreationDate:{$gte: ISODate("2016-08-02 15:39:14.947Z")},LastActivityDate:{$lt: ISODate("2016-10-08 04:44:18.407Z")}}},
{$unwind:"$Tags"},
{$group:{_id:"$Tags",TotalNoOfUsersParticipated:{$sum:"$numofUsersParticipated"}}},
{$sort:{"TotalNoOfUsersParticipated":-1}},
{$limit:5}
])