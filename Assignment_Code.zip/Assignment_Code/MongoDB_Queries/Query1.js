db.getCollection('post').aggregate([
{$addFields:{Comment_C:{$sum:"$Unaccepted_answer.CommentCount"},Comment_a:{$sum:"$accepted_answer.CommentCount"}}},
{$project:{Title:1,Tags:1,AnswerCount:1,Unaccepted_answer:1,accepted_answer:1,CommentCount:1,Comment_C:1,Comment_a:1,Intensity:{$sum:["$AnswerCount","$CommentCount","$Comment_C","$Comment_a"]}}},
{$unwind:"$Tags"},
{$match:{Tags:"neural-networks"}},
{$project:{Title:1,Tags:1,Intensity:1}},
{$sort:{Intensity:-1}},
{$limit:1}
])