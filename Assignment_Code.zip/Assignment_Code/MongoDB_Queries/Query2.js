db.post.aggregate([
{$project:{Tags:1,Title:1,CreationDate:1,LastActivityDate:1,comments:1,OwnerUserId:1,LastEditorUserId:1,Unaccepted_answer:1,accepted_answer:1,totalusers:1,Unaccepted:{$reduce:{input:"$Unaccepted_answer.comments.UserId",initialValue:[],in:{$concatArrays:["$$value","$$this"]}}},
accepted:{$reduce:{input:"$accepted_answer.comments.UserId",initialValue:[],in:{$concatArrays:["$$value","$$this"]}}}}},
{$addFields: { Users:["$Unaccepted_answer.LastEditorUserId","$accepted_answer.LastEditorUserId","$Unaccepted_answer.OwnerUserId","$accepted_answer.OwnerUserId","$comments.UserId","$Unaccepted","$accepted"]}},
{$project:{Tags:1,Title:1,CreationDate:1,LastActivityDate:1,Values:{$reduce:{input:"$Users",initialValue:["$OwnerUserId","$LastEditorUserId"],in:{$concatArrays:["$$value","$$this"]}}}}},
{$project:{Tags:1,Title:1,CreationDate:1,LastActivityDate:1,Values:{$setUnion:["$Values",[]]}}},
{$unwind:"$Values"},
{$lookup:{from:"Users",localField:"Values",foreignField:"_id",as:"User"}},
{$unwind:"$User"},
{$project:{Tags:1,Title:1,CreationDate:1,LastActivityDate:1,Values:1,Username:"$User.DisplayName",UpVotes:"$User.UpVotes"}},
{$unwind:"$Tags"},
{$group:{_id:"$Tags",MaxVote:{$max:"$UpVotes"}}},
{$lookup:{from:"Users",localField:"MaxVote",foreignField:"UpVotes",as:"User"}},
{$project:{Title:"$_id",MaxVote:1,UserId:"$User._id",Username:"$User.DisplayName"}},
{$match:{Title:"machine-learning"}}
])