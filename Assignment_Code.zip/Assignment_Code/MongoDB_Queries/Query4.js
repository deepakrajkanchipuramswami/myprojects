db.post.aggregate([
{$unwind: "$Unaccepted_answer"},
{$unwind: "$accepted_answer"},
{$match:{AnswerCount:{$gt:5}}},
{$match:{$expr:{$gt:["$Unaccepted_answer.Score", "$accepted_answer.Score"]}}},
{$project:{ArguableQuestions:"$Title"}}
])