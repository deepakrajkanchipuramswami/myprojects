db.post.aggregate([
{$match:{AcceptedAnswerId:{$exists:true}}},
{$addFields:{ac_Creation:"$accepted_answer.CreationDate"}},
{$project:{Title:1,Tags:1,CreationDate:1, Longest:{$max:"$ac_Creation"}}},
{$project:{Title:1,Tags:1,Time:{$divide:[{$subtract:["$Longest","$CreationDate"]},86400000]}}},
{$unwind:"$Tags"},
{$match:{Tags:"machine-learning"}},
{$sort:{Time:-1}},
{$limit:1}
])