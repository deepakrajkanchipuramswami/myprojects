*********README****************
Read, follow and execute all the README files in the Preprocessing folder to import appropriate data, build schema and indexes inorder to run the queries. Execute the README files in the following order.

->ReadMe_Preprocessing - The raw data will be processed using the python code(ADM_Preprocess.ipynb) and the steps to run the python will be provided here.
->Readme_MongoDB - Steps to import data(obtained from previous step) into MongoDB will be provided here. 
->Readme_neo4j - Steps to import data(obtained from preprocessing step) into neo4j will be provided here.


After executing all the queries provided in "Preprocessing" folder, follow the below steps to run the query.

***************MONGODB***********
1.After carrying out the steps corresponding to general preprocessing step, and preprocessing in MongoDB, Open Robo3T and Right Click --> New shell
2.Click Open icon at the top left corner of the Robo3T Screen.
3.In the dialog box, navigate to MongoDB_Queries submitted, and click on the first query to load the first query.
4.Click on the green "Run" button to execute the query.
5.Perform the same operation for all the queries under the folder "MongoDB_Queries" and acquire the output.

**************NEO4J***************
1.After carrying out the above operations and operations mentioned in neo4j preprocessing step, Open the Neo4j browser from Neo4j Desktop.
2.Once browser is active and contains all nodes and relationships, Navigate to the NEO4J_QUERIES submitted and open the text document named Query1
3.Copy paste the text from the document into the neo4j code tab and press run button.
4.Perform the same operation for all the queries under the folder "NEO4J_QUERIES" and acquire the output.
