function getJsonObject(path, success, error) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                if (success) success(JSON.parse(xhr.responseText));
            } else {
                if (error) error(xhr);
            }
        }
    };
    xhr.open("GET", path, true);
    xhr.send();
}

/*Main function to import books to HTML*/

function Books(bookList){
    tbody=document.getElementById("tbod");      //get the tobody element of HTML
    let cnt=bookList.length;
    console.log(cnt);
    var docy=document.getElementById("categoryselect");     //Get the select option from HTML
    var cat=[];
for (var i=0;i<=cnt;i++){                   
    var display=document.createElement("tr");               //Create a <tr> tag
    var selecelem=document.createElement("td");             //Create <td> tag for selection/checkbox element
    var imgelem=document.createElement("td");               //Create <td> tag for image element
    var innerelem=document.createElement("td");             //Create <td> tag for content element
    var innerrel=document.createElement("td");              //Create <td> for Rating element
    var arv=bookList[i];                                    //Get the first element
    //console.log(arv.category);
    let kay=arv.category;                                   //Get the category value for later use during filter
    let cen=cat.includes(kay);
    if (cen){}else{
    console.log(kay);
    cat.push(kay);
    console.log(cat);}                                      // create an array to store category values represented in filter
    if (i==1){                                              // If i=0; have the colspan value for 3rd <td> element be 3.All elements following that precedes the same
        var sec=document.createElement("section");          // Create section element
        var fig=document.createElement("figure");           //Create Figure element
        var division=document.createElement("div");         // Create division element
        let divat=document.createAttribute("class");        // Create division attribute
        divat.value="content";                              // set the value for division attribute
        var te=["","Title","Author","Year Published","Price","Rating","Publisher","Category"];
        division.setAttributeNode(divat);
        var ar=Object.values(arv);                          //get only the values from booklist object
        for (j=1;j<=7;j++){
            var p1=document.createElement("p"); 
            if (j==1){var a2=document.createAttribute("style");a2.value="word-break:break-word;";p1.setAttributeNode(a2);}            //Create a paragraph element to add json values
            if (j==5){continue;}
            if (j==4){var he=document.createTextNode(te[j] + ": $" + ar[j]);}   //add the json values along with title from te array
            else{
            var he=document.createTextNode(te[j] + " : " + ar[j]);}     //Create a textnode attribute to add values to <p>
            var a1=document.createAttribute("class");                   //add classname
            a1.value=te[j];
            p1.setAttributeNode(a1);
            p1.appendChild(he);                                         //append the attributes to <p> tag
            division.appendChild(p1);                                   //append the <p> tag to <division element>

        }
        fig.innerHTML="<img src=\"" + arv.img +"\" height=\"100\"; width=\"80\">";  //create the bookcover using figure element
        selecelem.innerHTML="<input type=\"checkbox\" name=\"" + "row" + i +"\" class=\"chk\">";    //add elements to checkbox elements
        let secat=document.createAttribute("class");            //create a attribute and add accordingly
        secat.value="book";                                     
        sec.setAttributeNode(secat);
        imgelem.appendChild(fig);                               //add the figure element inside seperate <td> element
        sec.appendChild(division);                              //add <div> to <sec> then to <td>
        innerelem.appendChild(sec);                             // add the above <sec> to div
        var secfig=document.createElement("section");           //create a section element for ratings <td> element
        var kat=document.createAttribute("id");
        kat.value="ratefig";
        secfig.innerHTML="<p class=\"ramp\"><font size=\"5\">"+ arv.rating + "/5" +"</font></p>"  //Add the value
        var ratimg=document.createElement("figure");            //Create a figure element
        ratimg.setAttributeNode(kat);
        for (f=1;f<=5;f++){
            if (f<=arv.rating){                                 //Create the number of full star based on rating 
                var tel=document.createElement("img");
                var telattr=document.createAttribute("src");
                telattr.value="images/\star-16.ico";
                var telattr2=document.createAttribute("class");
                telattr2.value="fig";
                tel.setAttributeNode(telattr2);
                tel.setAttributeNode(telattr);
                ratimg.appendChild(tel);
            }                                                   //create the number of hollow stars based on rating
            else{
                var tel=document.createElement("img");
                var telattr=document.createAttribute("src");
                telattr.value="images/\outline-star-16.ico";
                var telattr2=document.createAttribute("class");
                telattr2.value="fig";
                tel.setAttributeNode(telattr2);
                tel.setAttributeNode(telattr);
                ratimg.appendChild(tel);
                
            }
        }
        /*var tec=document.createAttribute("colspan");            //set the colspan for <td> element to 3
        tec.value=("3");
        innerrel.setAttributeNode(tec);*/
        innerrel.appendChild(secfig);                           //add rating(in number) to last <td>
        innerrel.appendChild(ratimg);                           //add rating(in image) to last <td>
        display.appendChild(selecelem);                         //add the first <td> to <tr>(checkbox)
        display.appendChild(imgelem);                           //add the second <td> to <tr>(image)
        display.appendChild(innerelem);                         //add the third <td> to <tr>(details)
        display.appendChild(innerrel);                          //add the fourth <td> to <tr>(ratings)
        console.log(display);
    }
    else{
        var sec=document.createElement("section");              // Create section element
        var fig=document.createElement("figure");               
        var selecelem=document.createElement("td");             
        var imgelem=document.createElement("td");               //Create Figure element        
        var division=document.createElement("div");             // Create division element
        let divat=document.createAttribute("class");            // Create division attribute
        divat.value="content";                                  // set the value for division attribute
        var te=["","Title","Author","Year Published","Price","Rating","Publisher","Category"];
        division.setAttributeNode(divat);
        var ar=Object.values(arv);                              //get only the values from booklist object
        for (j=1;j<=7;j++){
            var p1=document.createElement("p");                 //Create a paragraph element to add json values
            if (j==5){continue;}
            if (j==4){var he=document.createTextNode(te[j] + " : $" + ar[j]);}  //add the json values along with title from te array
            else{
            var he=document.createTextNode(te[j] + " : " + ar[j]);}         //Create a textnode attribute to add values to <p>
            var a1=document.createAttribute("class");                //add classname
            p1.appendChild(he);
            a1.value=te[j];
            p1.setAttributeNode(a1);                                //append the attributes to <p> tag
            division.appendChild(p1);                               //append the <p> tag to <division element>    

        }
        fig.innerHTML="<img src=\"" + arv.img +"\" height=\"100\"; width=\"80\">";  //create the bookcover using figure element
        selecelem.innerHTML="<input type=\"checkbox\" name=\"" + "row" + i +"\" class=\"chk\">";        //add elements to checkbox elements
        let secat=document.createAttribute("class");                //create a attribute and add accordingly
        secat.value="book";
        sec.setAttributeNode(secat);                                
        imgelem.appendChild(fig);                                    //add the figure element inside seperate <td> element
        sec.appendChild(division);
        innerelem.appendChild(sec);
        var secfig=document.createElement("section");               //create a section element for ratings <td> element
        secfig.innerHTML="<p class=\"ramp\"><font size=\"5\">"+ arv.rating + "/5" +"</font></p>" 
        var ratimg=document.createElement("figure");      
        for (t=1;t<=5;t++){
            if (t<=arv.rating){                                     //Create the number of full star based on rating 
                var tel=document.createElement("img");
                var telattr=document.createAttribute("src");
                telattr.value="images/\star-16.ico";
                var telattr2=document.createAttribute("class");
                telattr2.value="fig";
                tel.setAttributeNode(telattr2);
                tel.setAttributeNode(telattr);
                ratimg.appendChild(tel);
            }
            else{
                var tel=document.createElement("img");
                var telattr=document.createAttribute("src");
                telattr.value="images/\outline-star-16.ico";
                var telattr2=document.createAttribute("class");
                telattr2.value="fig";
                tel.setAttributeNode(telattr2);
                tel.setAttributeNode(telattr);
                ratimg.appendChild(tel);
                
            }
        }
        innerrel.appendChild(secfig);                           //add rating(in number) to last <td>
        innerrel.appendChild(ratimg);                           //add rating(in image) to last <td>
        display.appendChild(selecelem);                         //add the first <td> to <tr>(checkbox)
        display.appendChild(imgelem);                           //add the second <td> to <tr>(image)
        display.appendChild(innerelem);                         //add the third <td> to <tr>(details)
        display.appendChild(innerrel);                          //add the fourth <td> to <tr>(ratings)
        console.log(display);
    }tbody.appendChild(display);
    console.log(cat.length,i);                                  //Create the options under filter element
    if (i==9){
    for(let u=0;u<cat.length;u++) {
        console.log(cat[u]);
        docy.innerHTML+="<option>" +  cat[u] + "</option>"; }
}

}

}



window.onload=function(){                                   //invoked when the script runs
bookList = []; // book list container
getJsonObject('data.json',
    function(data) {
        bookList = data; // store the book list into bookList
        console.log(bookList); // print it into console (developer tools)
        console.log(bookList[0]); // print the first book object into console 
    Books(bookList);
    },
    function(xhr) { console.error(xhr); }
);
var filterlist=[];
//Search function
document.getElementById("clck").addEventListener("click",sam);          //Listen continuously whether the event is clicked.
function sam(){
    var serch=document.getElementById("search").value.toLowerCase();    //get the value and convert it to lowercase
    var val=document.getElementsByTagName("tr");                        //get all the <tr> elements under 
    var truelist=[];                                                    //array to identify whether any search matches the pattern. 
    if (filterlist.length>0){                                           //make the search function work with filter
            //console.log("This is filterlist" + filterlist);
            var selfil=[];
            for(k=1;k<val.length;k++){
                if(document.getElementById("dark").checked){val[k].style.backgroundColor="#808080";}else{
                val[k].style.backgroundColor="#FAFCFF";}                 //Initialize the background color to actual background color
                console.log(val[k].getElementsByTagName("p")[0]);
                if(filterlist.includes(val[k].getElementsByTagName("p")[0])){       //If the rows are in filtered rows(rows that are being displayed)
                   // console.log("im inside loop");
                    let samp=val[k].getElementsByTagName("p")[0];
                    if (samp.textContent.toLowerCase().includes(serch)){        //Check if the search text is in the filter displayed rows
                       // console.log("hi");
                    val[k].style.backgroundColor= "#FFC0CB";                    //if yes, color the rows
                    console.log(val[k]);
                    selfil.push(val[k]);                                        //push the row to the list to check if any search condition satisfies the request.
                }}
            }searcfilchk(selfil);
    }// if the array is empty, it means no elements match the pattern, then send the alert
    else{               
    for (i=1;i < val.length; i++){
        take=val[i].getElementsByTagName("p")[0];                       //get the title value from all the rows
        //console.log(take);
        if (take.textContent.toLowerCase().includes(serch)){            //check whether the <tr> elements contains search input
                val[i].style.backgroundColor= "#FFC0CB";                //change the backround color to pink
                console.log(val[i]);
                truelist.push(take);                                    //if the search matches any element, add it to array
        }else{
            if(document.getElementById("dark").checked){val[i].style.backgroundColor="#808080";}    //If darkmode is checked change the background accordingly
            else{val[i].style.backgroundColor="#FAFCFF";}               //make all other records to have same color
        }
    }if (truelist.length==0){alert("The book you are search for is currently unavailable");}}    // if the search doesn't have any match, return alert.
    console.log(serch);} 

function searcfilchk(selfil){if(selfil.length==0){alert("Your selected books is not in this category.please select another one");}}

//Filter function
document.getElementById("filte").addEventListener("click",sel);         //Listen continuously whether the event is clicked.

function sel(){
        var filt=document.getElementById("categoryselect").value.toLowerCase(); //get the category and convert it to lowercase
         console.log(filt);
        filterlist=[];                                                      //array to identify whether any filter matches the pattern. 
        if (filt.includes("select")){                                           //loop  to display all the elements
            valu=document.getElementsByTagName("tr");
            for (i=1;i < valu.length; i++){
                valu[i].style.display="";
            }
        }
        else{
        valu=document.getElementsByTagName("tr");                       //get all the <tr> elements under                       
        for (i=1;i < valu.length; i++){
            taker=valu[i].getElementsByTagName("p")[5];                 //get the category value from all the rows
            if (taker.textContent.toLowerCase().includes(filt)){        //check whether the <tr> elements contains filter input
                filterlist.push(valu[i].getElementsByTagName("p")[0]);  //if the filter matches any element, add it to array
                valu[i].style.display="";                               //no changes to the display value 
                console.log(filterlist.length);
            }
            else{
                valu[i].style.display="none";                           //Hide all other elements by setting their display value to none
            }
            }}
            console.log(filterlist);
            if(filterlist.length==10 || filterlist.length==0){alert("Please select the appropriate category");
            valu=document.getElementsByTagName("tr");                   //get all the <tr> elements under
            for (i=1;i < valu.length; i++){
                valu[i].style.display="";                               //Display all the elements after the error message
            }}
    }

//Add to Cart function

document.getElementById("formsubmit").addEventListener("click",addcart);    //Check whether the add to cart button is clicked

var cart_hold=new Set();                                                    //Create a set to store distinct books
var quantity=0;                                                             //Initialize the quantity button
var cartobj={};                                                             //Object to store key value pairs of selected books: quantity
ckdcnt=0;                                       
function addcart(){
    var ty=prom();                                                          //invoke the prom function
    var atob=[];                                                            //initialize the array
    if(ty=="no"){console.log(cart_hold);return;}                            //If the function returns "no", exit the function
    else{               
    var getrow=document.getElementById("tbod").childNodes;                  //get all the rows in table
    var row_count=getrow.length;                                            //get the length
    console.log(getrow);
    console.log(row_count);
    for (i=1;i<row_count;i++){
        let ckd=getrow[i].querySelector(".chk").checked;                    //Check if the row is selected
        let dis=getrow[i].querySelector(".chk").disabled;                   //Check if the row is disabled
        if (dis==true){continue;}                                           //Don't count the disabled row
        else{
        console.log(ckdcnt,ckd);                    
        if (ckd){atob.push(getrow[i]);}                                     //push the row into the table
        if (atob.length>1) {alert("Please select one book at a time. Adding only one book");break;}     //if the number of books is more than 1, alert the user
        if (ckd==true && ckdcnt==0){grow(ckd,getrow[i],ty);ckdcnt+=1;}      //if any row is selected invoke the function. ckdcnt is incremented once the value becomes true.
        }ckdcnt=0;console.log(cartobj);console.log(quantity);console.log(cart_hold); //output the value.
    }}}
    function prom(){                                                        //Prompt to enter the number of books to be added
        var quant=prompt("Enter the Quantity");                             //Create the prompt window
        let yum=parseInt(quant);                                            //Get the value and parse the value as int
        if (isNaN(yum)){                                                    //If the input value is string or invalid, alert the user
            alert("Invalid Number!. Please try again. No books added");
            return "no";
        }else{
            return quant;                                                   //else return the value
        }
        }
    function grow(ckd,gettr,ty){
        if(ckd==true){
            let vali=gettr.getElementsByTagName("p")[0].innerHTML;          //if any value is checked, get the title of the book
            cartobj[vali] = ty;                                             //get the key value pair for the book:quantity
            cart_hold.add(gettr);                                           //store the book in cart
            quantity+=parseInt(ty);                                         //add the value to quantity
            gettr.querySelector(".chk").disabled=true;                      //disable the row if the book is selected
    }document.getElementById("cartquantity").innerHTML="(" + quantity +")";     //update the cart icon
}

//show the book and it's quantity when clicking shopping cart icon
document.getElementById("shop").addEventListener("click",show);         //Add the listener to check whether the cart is clicked
function show(){alert(Object.keys(cartobj) + ":" + Object.values(cartobj));console.log(quantity);console.log(cart_hold);}   //show the cart elements

document.getElementById("clr").addEventListener("click",resetcart);        //Check whether the reset button is clicked

function resetcart(){
    console.log(quantity);
    console.log(cart_hold);
    console.log(cartobj);
    var confir=confirm("You are going to clear the cart.Are you OK?");              //alert the user for the cart clearance
    if (confir==true){      
        var getro=document.getElementById("tbod").childNodes;
        let row_cnt=getro.length;
        for (i=1;i<row_cnt;i++){
            let dis=getro[i].querySelector(".chk").disabled;
            if (dis){getro[i].querySelector(".chk").disabled=false;getro[i].querySelector(".chk").checked=false;}}  //disable the uncheck feature and uncheck the row
        quantity=0;
        cart_hold.clear();                                                          //clear all the elements in the cart and set the quantity to zero
        for (var valp in cartobj){                                                  //delete the quantity show option.
            delete cartobj[valp];
        }
    }document.getElementById("cartquantity").innerHTML="(" + quantity +")";         //update the option in figure
    
    console.log(cart_hold);
    
    }

    //Dark Mode Feature
document.getElementById("dark").addEventListener("click",darkmode);             //check if te dark mode is enabled
function darkmode(){
    if (document.getElementById("dark").checked==true){                         //check if the dark mode feature is activated
        document.body.style.backgroundColor="#808080";
        document.getElementById("tbl").style.backgroundColor="#808080";
        document.getElementById("searchBox").style.backgroundColor="#808080";
        document.getElementById("tbod").style.backgroundColor="#808080";
        document.getElementById("thd").style.backgroundColor="#66CCCC";
        document.getElementById("listBox").style.backgroundColor="#808080";
        document.getElementById("search").style.backgroundColor="#95BEF0";
        document.getElementById("categoryselect").style.backgroundColor="#95BEF0";
        document.getElementById("clck").style.backgroundColor="#32CD32";
        document.getElementById("filte").style.backgroundColor="#32CD32";
        document.getElementById("formsubmit").style.backgroundColor="#32CD32";
        document.getElementById("clr").style.backgroundColor="#32CD32";
        document.getElementById("Heading").style.color="#32CD32";
        document.getElementById("lbl").style.color="#FFFFFF";
        var dum=document.getElementsByTagName("p");                             //get all the <p> elements and change its value
        for (var r in dum){dum[r].style.color="#FFFF00";}                       //change all the row values to yellow
    }
}
}

/*References: https://www.w3schools.com/js/  */